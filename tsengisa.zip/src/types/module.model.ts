export interface ModuleDefinition {
    name:string,
    link:string,
    icon:string
}