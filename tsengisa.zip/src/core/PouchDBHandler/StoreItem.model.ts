export interface IStoreItem {
    id:string,
    name:string,
    date_added:string,
    purchase_prize:number,
    resell_prize:number,
    quantity:number,
    category:string,
}