const dummyStoreItems = [
  {
    id: '6001069033613',
    name: 'Yum Yum Peanut butter',
    date_added: new Date,
    purchase_prize: 50,
    resell_prize: 60,
    quantity: 5,
    category: 'food',
  },
  {
    id: '6001065662000',
    name: 'Tennis coconut biscuits',
    date_added: new Date,
    purchase_prize: 15,
    resell_prize: 21.5,
    quantity: 10,
    category: 'food',
  },
  {
    id: '6001087375108',
    name: 'Axe Gold',
    date_added: new Date,
    purchase_prize: 20,
    resell_prize: 30,
    quantity: 10,
    category: 'Sanitery',
  },
];


