export enum AppEmisions {
  'CLICKED_TOBAR_MENU' = 'click_topbar_menu',
  'SET_ACTIVE_ITEM_SIDEBAR' = 'set_active_item_sidebar',
  'CLOSE_SIDE_MENU' = 'close_side_menu',
  'BARCODE_VALUE' = 'barcode_value'
}
