import { ActionTree } from "vuex";
import { STATE_MUTATIONS } from "./mutations";
import { StateInterface } from "./state";

export enum STATE_ACTIONS {
 
}

const actions: ActionTree<StateInterface, StateInterface> = {
  
};

export default actions;
