import { GetterTree } from 'vuex';
 import { StateInterface } from './state';


 export enum GETTERS {
  
 }

 const getters: GetterTree<StateInterface, StateInterface> = {
   
 };

 export default getters;