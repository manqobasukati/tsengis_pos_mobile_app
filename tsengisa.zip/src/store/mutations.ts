
import { MutationTree } from "vuex";
import { StateInterface } from "./state";

export enum STATE_MUTATIONS {
  
}

const mutations: MutationTree<StateInterface> = {

};

export default mutations;
