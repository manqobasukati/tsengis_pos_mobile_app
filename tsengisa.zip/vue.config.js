module.exports = {
    devServer: {
      https: true
    }
  }